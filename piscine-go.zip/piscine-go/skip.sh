#!/usr/bin/env bash

ls -l | sed -n 'n;p'
