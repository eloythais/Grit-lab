package main

import (
	github.com/01-edu/z01
)

func main () {

for i := 'a'

}