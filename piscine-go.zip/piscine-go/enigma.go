package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	*******c, ****d, *b, ***a = ***a, *******c, ****d, *b
}
