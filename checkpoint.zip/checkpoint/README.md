Only a
Only z
Printalphabet
Printreversealphabet
Printdigit
Strlen
Swap
Fish and chip
Countcharacter 
Countalpha
Checknumber
Digitlen
Atoi
Printcomb
Fromto
Capitalize 
Itoa
Weareunique
Printrevcomb
Printmemory
Iscapitalized 
Findprevprime 
Thirdtimesacharm
Saveandmiss
Concatslice
Union
Inter
Reversestrcap
Wdmatch


Quest-6
Fifthandskip
Slice
Revconcatalternate
Notdecimal
Wordflip
Split# checkout-3
