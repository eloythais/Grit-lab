// https://github.com/01-edu/public/tree/master/subjects/onlyz

package piscine

import "github.com/01-edu/z01"

func OnlyZ() {
	// Print a single character using PrintRune
	z01.PrintRune('z')
}
