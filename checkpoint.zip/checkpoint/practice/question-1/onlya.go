package piscine

import "github.com/01-edu/z01"

func OnlyA() {
	// Print a single character using PrintRune
	z01.PrintRune('a')
}
