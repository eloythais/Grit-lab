// https://github.com/01-edu/public/tree/master/subjects/itoa

package piscine

import "strconv"

func Itoa(n int) string {
	return strconv.Itoa(n)
}
