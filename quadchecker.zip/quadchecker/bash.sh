go build quadA.go
go build quadB.go
go build quadC.go
go build quadD.go
go build quadE.go
rm quadA.go
rm quadB.go
rm quadC.go
rm quadD.go
rm quadE.go